/*import React from 'react';

const ReviewList = ({ reviews }) => {
  return (
    <div className="mt-4">
      <h3 className="text-xl font-bold mb-2">리뷰 ({reviews.length})</h3>
      {reviews.map((review, index) => (
        <div key={index} className="border-b py-2">
          <strong>{review.user}</strong>: {review.comment}
        </div>
      ))}
    </div>
  );
};

export default ReviewList;*/
