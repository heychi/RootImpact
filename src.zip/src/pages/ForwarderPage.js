import React from 'react';
import ForwarderDetail from '../components/Forwarder/ForwarderDetail';

const ForwarderPage = () => {
  return (
    <div className="p-4">
      <ForwarderDetail />
    </div>
  );
};

export default ForwarderPage;
