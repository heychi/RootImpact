import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div className="p-4 text-center">
      <p className="text-lg mb-4">
        디지털 포워딩 매칭 플랫폼에 오신 걸 환영합니다!
      </p>
      <Link to="/forwarding-platform">포워더 상세</Link>
      <br></br>
      <br></br>
      <Link to="/chat" className="chat-link">
        채팅 페이지로 이동 →
      </Link>
    </div>
  );
};

export default Home;
